import React, { useState, useEffect } from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Container from 'react-bootstrap/Container';
import { Row, Col, Button, Form } from 'react-bootstrap';
import SearchIcon from '@mui/icons-material/Search';
import InputBase from '@mui/material/InputBase';
import Table from 'react-bootstrap/Table';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import Stack from '@mui/material/Stack';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import AddIcon from './icons/add-icon.svg';
import UpdateIcon from './icons/update-icon.svg';
import { Routes, Route, NavLink, useNavigate } from 'react-router-dom';
import {
  Id,
  Name,
  Radio,
  No,
  Btn,
  Dropdown,
  Radiothree,
  Topbutton1,
  Topbutton,
} from "../Input.js";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import Card from "react-bootstrap/Card";


const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: theme.palette.common.white,
  '&:hover': {
    backgroundColor: theme.palette.common.white,
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(3),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: 'black',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'black',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: '20ch',
    },
  },
}));



function UserGeneral_entry_sales() {
  const breadcrumbs = [
    <Link underline="hover" key="1" color="inherit">
      General Entry
    </Link>,
    <Link
      underline="hover"
      key="2"
      color="white"
    >
      Sales
    </Link>
  ];

  const [showPurchaseForm, setShowPurchaseForm] = useState(false);
  const [showQuitForm, setShowQuitForm] = useState(false);
  const [selectedVal,setSelectedVal] = useState({})
  const handlePurchaseButtonClick = (val) => {
    if (val === "purchase") {
      setShowPurchaseForm(false);
      setShowQuitForm(false);
    } else if (val === "payment") {
      setShowPurchaseForm(false);
      setShowQuitForm(true);
    }
  };

  // useEffect to set the initial state
  useEffect(() => {
    setShowPurchaseForm(true);
    setShowQuitForm(false);
  }, []); // Empty dependency array ensures that this effect runs only once after the initial render

  const [isModalOpen, setIsModalOpen] = useState(true);

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleDelete = () => {
    setIsModalOpen(false);
  };

// deletesection
const deleteData=async()=>{
  let payload={
    salesId:selectedVal?.sales_id
  }
  // console.log(payload);
  await axios.post(`https://vebbox.in/gvmbackend/controllers/api/delete/salesDelete.php`,payload).then(res=>{
    if(res.data.message==="deleted"){
      // alert("deleted succussfully");
      toast.success("Deleted Successfully!");
      setShowPurchaseForm(true);
      setShowQuitForm(true);
      fetchData()
    }
  }).catch(err=>{
    console.log(err);
  })
}

  const handleCancelClick = () => {
    setShowPurchaseForm(true);
    setShowQuitForm(false);
  };

  // fetch axios
  const [purchaseData, setPurchaseData] = useState([]);

  const fetchData = async () => {
    try {
      const response = await axios.get(
        "https://vebbox.in/gvmbackend/controllers/api/get/viewSales.php"
      );
      setPurchaseData(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);


  return (
    <>
      <div style={{ backgroundColor: '#3d3b52', borderRadius: '20px', paddingBottom: '50px' }}>
        <Container fluid>
          <Row>
            <Stack spacing={3} style={{ marginTop: '30px' }}>
              <Breadcrumbs separator={<NavigateNextIcon fontSize="small" />} aria-label="breadcrumb">
                {breadcrumbs}
              </Breadcrumbs>
            </Stack>
            {/* <Col xs={12} md={8} lg={6} className="d-grid gap-2 mt-5">
              <NavLink to="/user_generalentry" className="ul">
                <Button size="lg" style={buttonStyle} >
                  Purchase
                </Button>
              </NavLink>
            </Col>
            <Col xs={12} md={8} lg={6} className="d-grid gap-2 mt-5">
              <NavLink to="/user_generalentry_sales" className="ul">
                <Button size="lg" style={buttonStyle1} >
                  Sales
                </Button>
              </NavLink>
            </Col> */}

            <Col xs={12} md={8} lg={6} className="d-grid gap-2 mt-5">
              <NavLink to="/user_generalentry" className="ul">
                <Topbutton1 topname="Purchase" />
              </NavLink>
            </Col>
            <Col xs={12} md={8} lg={6} className="d-grid gap-2 mt-5">
              <NavLink to="/user_generalentry_sales" className="ul">
                <Topbutton topname="Sales" />
              </NavLink>
            </Col>
          </Row>

          <Row>
            <Col xs={12} md={8} lg={6} className="d-grid gap-2 mt-5">
              <Search className="search" style={{ position: "absolute" }}>
                <SearchIconWrapper>
                  <SearchIcon className="search-icon" />
                </SearchIconWrapper>
                <StyledInputBase
                  placeholder="Search…"
                  inputProps={{ 'aria-label': 'search' }}
                  style={{ width: "450px" }}
                />
              </Search>
            </Col>
            <Col xs={12} md={8} lg={3} className="d-grid gap-2 mt-5 text-center">
              <NavLink to="/user_updatesales" className="ul">
                <Button size="lg" style={{ backgroundColor: '#babaef', color: 'black', width: '100%' }}>
                  <img src={UpdateIcon} alt="update icon" className="updatebtn" />
                  Update</Button>
              </NavLink>
            </Col>
            <Col xs={12} md={8} lg={3} className="d-grid gap-2 mt-5 text-center">
              <NavLink to="/user_addsales" className="ul">
                <Button size="lg" style={{ backgroundColor: 'white', color: 'black', width: '100%' }}>
                  <img src={AddIcon} alt="update icon" className="updatebtn" />
                  Add</Button>
              </NavLink>
            </Col>
            <Col xs={12} md={8} lg={12} className="d-grid gap-2 mt-5">
            <div style={{ overflowX: "auto", maxWidth: "100%" }}>
            <Table bordered className="table-center">
        <thead>
          <tr>
          <th>sales_id</th>
          <th>customer_name</th>
          <th>customer_id</th>
          <th>customer_type</th>
          <th>product_name</th>
          <th>product_quantity</th>
          <th>total_amount</th>
          <th>total_amount1</th>
          <th>paid_amount</th>
          <th>balance_amount</th>
          <th>payment_method</th>
          <th>payment_mode</th>
          <th>payment_type</th>
          <th>vehicle_no</th>
          <th>driver_name</th>
          <th>chassic_no</th>
          <th>rcbook_no</th>
          <th>product_quantity1</th>
          <th>fuel_liter</th>
          <th>fuel_amount</th>
          <th>location</th>
          <th>date</th>
          <th>wages</th>
          <th>wages_type</th>
          {/* <th>Action</th> */}
          </tr>
        </thead>
        <tbody>
          {purchaseData.map((purchase) => (
            <tr key={purchase.sales_id}>
              <td>{purchase.sales_id}</td>
              <td>{purchase.customer_name}</td>
              <td>{purchase.customer_id}</td>
              <td>{purchase.customer_type}</td>
              <td>{purchase.product_name}</td>
              <td>{purchase.product_quantity}</td>
              <td>{purchase.total_amount}</td>
              <td>{purchase.total_amount1}</td>
              <td>{purchase.paid_amount}</td>
              <td>{purchase.balance_amount}</td>
              <td>{purchase.payment_method}</td>
              <td>{purchase.payment_mode}</td>
              <td>{purchase.payment_type}</td>
              <td>{purchase.vehicle_no}</td>
              <td>{purchase.driver_name}</td>
              <td>{purchase.chassic_no}</td>
              <td>{purchase.rcbook_no}</td>
              <td>{purchase.product_quantity1}</td>
              <td>{purchase.fuel_liter}</td>
              <td>{purchase.fuel_amount}</td>
              <td>{purchase.location}</td>
              <td>{purchase.date}</td>
              <td>{purchase.wages}</td>
              <td>{purchase.wages_type}</td>
              {/* <td>
                <button
                  style={{ border: "none", backgroundColor: "inherit" }}
                  onClick={() =>{ handlePurchaseButtonClick("purchase");setSelectedVal(purchase)}}
                >
                  <DeleteIcon />
                </button>
              </td> */}
            </tr>
          ))}
        </tbody>
      </Table>
      </div>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
}
export default UserGeneral_entry_sales;