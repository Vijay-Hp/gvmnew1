export const EDIT = "Edit";
export const DELETE = "Delete";
export const EDIT_RENTAL_HISTORY = "editRentalHistory";
